# Gold Standard Pressure Washing — Website

A 4-page marketing website for Gold Standard Pressure Washing, serving
Riverbend and south Edmonton, Alberta. Plain HTML/CSS/JS — no build step,
no framework, deploys anywhere.

## Pages

- `index.html` — Home (hero, services, why us, FAQ)
- `services.html` — Driveway & concrete, deck & fence, square footage estimator
- `about.html` — About the business
- `contact.html` — Contact form + phone/email
- `thank-you.html` — Shown after a contact form submission

The Gallery page has been removed for now until real before/after job
photos are available. Re-add `gallery.html` and its nav link once you have
photos to show.

## Running locally

No build needed. Just open `index.html` in a browser, or serve the folder:

```bash
npx serve .
```

## Contact info

The site is live with real contact info:

- Phone: 587-905-6233
- Email: Luke@gold-standard-pressure-washing.ca

Remember: the first contact form submission triggers a FormSubmit
confirmation email to that address — click the link in it before
further submissions will be delivered (see "Contact form" below).

## Contact form

The contact form submits to [FormSubmit.co](https://formsubmit.co), which
emails submissions straight to the address in the form's `action` URL, with
no backend or account required.

**Important:** the first time the form is submitted, FormSubmit sends a
one-time confirmation email to that address. You must click the
confirmation link in that email before further submissions will be
delivered. After that, it works automatically.

Only Name, Phone, and Project Description are required — Email and Address
are optional fields for the customer.

## Pricing Calculator

The tabbed calculator (embedded in `services.html`, also standalone in
`pricing.html`) gives an instant estimate from a square-footage slider
(25 sq ft steps):

- **Driveway + walkway wash** — $150–$185 range up to 600 sq ft, then
  +$25 per 100 sq ft (or part thereof) on the low end, high = low × 1.25
- **Sealing** — single price: `200 + max(0, sqft - 400) × $0.70`.
  Base $200 covers up to 400 sq ft (a standard single-car driveway).
- **Driveway + sealing package** — single price: wash $150 flat + the
  sealing price above − $50 bundle discount. The discount is shown to
  the customer under the price.
- **Deck wash** — $200–$250 range up to 400 sq ft, then +$0.40/sq ft on
  the low end, high = low × 1.25

These rates are estimate-only; the displayed note always clarifies that
final pricing is confirmed on-site.

## Placeholder images

All photos currently come from inline-generated SVG placeholders as
stand-ins. Replace the `src` attributes in the HTML with real job photos
when you have them — recommended size ~700x560 for hero/about images,
~500x400 for service cards.

## Deploying

Since this is a static site, any of these work with zero configuration:

- **Netlify** — drag-and-drop the folder onto [app.netlify.com/drop](https://app.netlify.com/drop), or connect the GitHub repo for continuous deployment
- **GitHub Pages** — push to a repo, enable Pages on the `main` branch
- **Vercel** — `vercel deploy` from this folder
